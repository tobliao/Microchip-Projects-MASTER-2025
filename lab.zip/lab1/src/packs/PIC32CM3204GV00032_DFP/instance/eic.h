/*
 * Instance header file for PIC32CM3204GV00064
 *
 * Copyright (c) 2025 Microchip Technology Inc. and its subsidiaries.
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

/* file generated from device description file (ATDF) version 2019-11-25T23:26:27Z */
#ifndef _PIC32CMGV00_EIC_INSTANCE_
#define _PIC32CMGV00_EIC_INSTANCE_


/* ========== Instance Parameter definitions for EIC peripheral ========== */
#define EIC_CONFIG_NUM                           (2)        /* Number of CONFIG registers */
#define EIC_EXTINT_NUM                           (16)       /* Number of External Interrupts */
#define EIC_GCLK_ID                              (3)        /* Index of Generic Clock */
#define EIC_INSTANCE_ID                          (6)        
#define EIC_NUMBER_OF_CONFIG_REGS                (2)        /* Number of CONFIG registers (obsolete) */
#define EIC_NUMBER_OF_INTERRUPTS                 (16)       /* Number of External Interrupts (obsolete) */

#endif /* _PIC32CMGV00_EIC_INSTANCE_ */
